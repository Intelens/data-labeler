"""Bring your own data into pragmatiq: data/bronze (raw text) -> data/silver (pragmatiq contract) -> model.

  python pipeline.py silver     # bronze txt -> validated parquet, split train / test
  python pipeline.py tokenize   # fit the tokenizer on TRAIN customers, write token shards
                                                      # (+ forecast records: history + hidden next-event stub)
  python pipeline.py prepare    # silver + tokenize
  python pipeline.py train      # pretrain the event model on those shards; every step also
                                                      # writes one example of what it trained on (examples.jsonl)

Bronze: data/bronze/<customer_id>.txt, one event per line, tab-separated:
    timestamp  source  event  key=value  key=value ...
  timestamp ISO 8601 in UTC; source one of transaction | app | trading | communication.
  Optional data/bronze/profiles.txt, one customer per line:  customer_id  key=value  key=value ...
  (age, monthly income, plan: the tokenizer encodes them as the customer's profile).
Silver: pragmatiq's bring-your-own-data contract (README "Using your own data"), split by customer
  into train/ and test/, each with
  events.parquet    user_id, ts timestamp[us], source, fields map<str,str> (event name under "event"),
                    sorted by (user_id, ts)
  profiles.parquet  one row per customer, as_of = last event, attributes from profiles.txt
  plus split.json   which customers are in the test set (seeded, 20%)
Gold: data/gold/tok (tokenizer + shards, train customers only), models/<name> (checkpoints, metrics.jsonl).
Any python can launch this: it re-runs itself under .venv (made by start.sh) in UTF-8 mode (needed on Windows).
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from importlib.util import find_spec
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BRONZE, SILVER = ROOT / "data" / "bronze", ROOT / "data" / "silver"
TOK, MODELS = ROOT / "data" / "gold" / "tok", ROOT / "models"
FC, FC_N, FC_TAG = ROOT / "data" / "gold" / "forecast", 3, "#next"  # forecast records: <customer>#next<k>, see tokenize
VENV_PY = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")  # made by start.sh
PROFILES = "profiles.txt"
# Hybrid, like PRAGMA's text variant: these fields are free text. Each reaches the model as one token whose value is
# a vector from a frozen text encoder, so similar wording gets a similar input, and a message never seen before
# still gets a meaningful one. The rest stays key/value tokens.
TEXT_KEYS = ("subject", "message", "script", "banner", "notes")
TEXT_ENCODER, TEXT_DIM = "words", 64
TEST_SHARE, SPLIT_SEED = 0.2, 0


def parse_line(line: str) -> tuple[int, str, list[tuple[str, str]]]:
    """One bronze line -> (ts in us, source, fields with the event name under "event"); ValueError if malformed."""
    import numpy as np

    ts, source, event, *kv = line.split("\t")
    fields = [("event", event)] + [tuple(x.split("=", 1)) for x in kv]
    if any(len(f) != 2 for f in fields):  # a field without '='
        raise ValueError(line)
    return int(np.datetime64(ts, "us").astype(np.int64)), source, fields


def parse_profile_line(line: str) -> tuple[str, list[tuple[str, str]]]:
    """One profiles.txt line -> (customer id, attributes); ValueError if malformed."""
    uid, *kv = line.split("\t")
    attrs = [tuple(x.split("=", 1)) for x in kv]
    if not uid or any(len(a) != 2 for a in attrs):
        raise ValueError(line)
    return uid, attrs


def silver() -> None:
    import numpy as np
    import pyarrow as pa
    import pyarrow.compute as pc
    import pyarrow.parquet as pq

    from pragmatiq import api
    from pragmatiq.core.schema import EVENTS_SCHEMA, PROFILES_SCHEMA

    files = sorted(p for p in BRONZE.glob("*.txt") if p.name != PROFILES)
    if not files:
        raise SystemExit(f"no bronze files in {BRONZE}")
    cols: dict[str, list] = {"user_id": [], "ts": [], "source": [], "fields": []}
    for path in files:
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                ts, source, fields = parse_line(line)
            except ValueError:
                raise SystemExit(f"{path.name}:{n}: expected 'timestamp<TAB>source<TAB>event[<TAB>key=value...]',"
                                 f" got {line!r}") from None
            cols["ts"].append(ts)
            cols["user_id"].append(path.stem)
            cols["source"].append(source)
            cols["fields"].append(fields)
    attrs: dict[str, list] = {}
    if (BRONZE / PROFILES).exists():
        for n, line in enumerate((BRONZE / PROFILES).read_text(encoding="utf-8").splitlines(), 1):
            if line.strip():
                try:
                    uid, a = parse_profile_line(line)
                except ValueError:
                    raise SystemExit(f"{PROFILES}:{n}: expected 'customer_id<TAB>key=value...', got {line!r}") from None
                attrs[uid] = a

    events = pa.Table.from_pydict(cols, schema=EVENTS_SCHEMA).sort_by([("user_id", "ascending"), ("ts", "ascending")])
    last = events.group_by("user_id").aggregate([("ts", "max")]).sort_by("user_id")
    ids = last["user_id"].to_pylist()
    profiles = pa.Table.from_pydict({"user_id": ids, "as_of": last["ts_max"], "attributes": [attrs.get(u, []) for u in ids],
                                     "lifelong": [[]] * len(ids)}, schema=PROFILES_SCHEMA)
    # Split by customer, seeded: the tokenizer and the model only ever see train customers; quality is measured on test.
    test = sorted(np.random.default_rng(SPLIT_SEED).choice(ids, int(len(ids) * TEST_SHARE), replace=False).tolist())
    shutil.rmtree(SILVER, ignore_errors=True)
    for part in ("train", "test"):
        keep = pc.is_in(events["user_id"], value_set=pa.array(test))
        keep_p = pc.is_in(profiles["user_id"], value_set=pa.array(test))
        if part == "train":
            keep, keep_p = pc.invert(keep), pc.invert(keep_p)
        (SILVER / part).mkdir(parents=True)
        pq.write_table(events.filter(keep), SILVER / part / "events.parquet")
        pq.write_table(profiles.filter(keep_p), SILVER / part / "profiles.parquet")
        report = api.validate(SILVER / part)  # pragmatiq's contract check: dtypes, sources, ordering, cardinality
        print(f"{part}: {events.filter(keep).num_rows:,} events, {profiles.filter(keep_p).num_rows:,} customers"
              f" -> {SILVER / part}  {report['summary']}")
        for w in report["warnings"]:
            print("warning:", w)
        if not report["ok"]:
            raise SystemExit("\n".join(report["errors"]))
    (SILVER / "split.json").write_text(json.dumps({"seed": SPLIT_SEED, "test_share": TEST_SHARE, "train": len(ids) - len(test),
                                                   "test": len(test), "test_ids": test}), encoding="utf-8")
    keys = ", ".join(k for k, _ in next(iter(attrs.values()), []))
    print(f"profiles: {len(attrs):,} customers with attributes ({keys or 'none'})")


def forecast_records(out: Path) -> int:
    """Train customers, plus FC_N extra records each: the history cut after a random event, then a stub of the
    event that really came next (its time, source and event name only). The pragma_forecast masker always hides
    the stub, so pretraining also learns to name the next event (with keys visible it never had to: they give
    the event type away). Test customers are not touched."""
    import numpy as np
    import pyarrow as pa
    import pyarrow.parquet as pq

    from pragmatiq.core.schema import EVENTS_SCHEMA, PROFILES_SCHEMA

    rows = pq.read_table(SILVER / "train" / "events.parquet").to_pylist()  # sorted by (user_id, ts)
    prof = {p["user_id"]: p for p in pq.read_table(SILVER / "train" / "profiles.parquet").to_pylist()}
    by: dict[str, list] = {}
    for r in rows:
        by.setdefault(r["user_id"], []).append(r)
    rng, extra, extra_p = np.random.default_rng(SPLIT_SEED), [], []
    for u, rs in by.items():
        for k, i in enumerate(sorted(rng.choice(len(rs) - 1, min(FC_N, len(rs) - 1), replace=False))):
            nxt, uid = rs[i + 1], f"{u}{FC_TAG}{k}"
            extra += [{**r, "user_id": uid} for r in rs[: i + 1]]
            extra.append({"user_id": uid, "ts": nxt["ts"], "source": nxt["source"], "fields": [("event", dict(nxt["fields"])["event"])]})
            extra_p.append({**prof[u], "user_id": uid, "as_of": nxt["ts"]})
    out.mkdir(parents=True, exist_ok=True)  # each record's rows stay together and in time order: no re-sort needed
    pq.write_table(pa.Table.from_pylist(rows + extra, schema=EVENTS_SCHEMA), out / "events.parquet")
    pq.write_table(pa.Table.from_pylist(list(prof.values()) + extra_p, schema=PROFILES_SCHEMA), out / "profiles.parquet")
    return len(extra_p)


def text_encoder() -> str:
    """Register the frozen text encoder (once per process: training, server, decision models) and return its name.
    ponytail: words and character trigrams hashed to fixed random vectors, summed: offline and instant; similar
    wording gives similar vectors, but it knows no synonyms. A pretrained sentence model (Revolut's paper uses
    Nemotron) is a drop-in: register it under this name, set TEXT_DIM to its width, and retokenize and retrain."""
    from pragmatiq.registry import TEXT_ENCODERS, register_text_encoder

    if TEXT_ENCODER not in TEXT_ENCODERS:
        @register_text_encoder(TEXT_ENCODER)
        class WordsTextEncoder:
            def __init__(self, dim: int = TEXT_DIM) -> None:
                self.dim, self._cache = dim, {}

            def _vec(self, text: str):
                import hashlib
                import re

                import torch

                v = self._cache.get(text)
                if v is None:
                    v = torch.zeros(self.dim)
                    for w in re.findall(r"\w+", text.lower()):
                        for f, wt in [(w, 1.0)] + [("#" + w[i:i + 3], 0.3) for i in range(max(1, len(w) - 2))]:
                            g = torch.Generator().manual_seed(int(hashlib.sha1(f.encode()).hexdigest()[:15], 16))
                            v += wt * torch.randn(self.dim, generator=g)
                    v = self._cache[text] = v / (v.norm() + 1e-9) * self.dim ** 0.5  # same scale as pragmatiq's "hash"
                return v

            def encode(self, texts):
                import torch

                return torch.stack([self._vec(t or "") for t in texts]) if texts else torch.zeros(0, self.dim)

    return TEXT_ENCODER


def compact_index(idx: Path) -> None:
    """pragmatiq's LMDB user index reserves 16 GB, which on Windows is a 16 GB (sparse) file that zip / scp read in
    full; a compact copy holds only the used pages (a few MB), so the folder copies to a VM. Readers open it read-only."""
    import lmdb

    tmp = idx.with_name(idx.name + ".compact")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    with lmdb.open(str(idx), readonly=True, lock=False) as env:
        env.copy(str(tmp), compact=True)
    shutil.rmtree(idx)
    tmp.rename(idx)


def tokenize() -> None:
    from pragmatiq import api
    from pragmatiq.data.tokenizer import PragmaTokenizer, TokenizerConfig

    shutil.rmtree(TOK, ignore_errors=True)  # derived: stale shards must not leak into the next run
    shutil.rmtree(FC, ignore_errors=True)
    # Fit a fresh tokenizer on TRAIN customers only: test customers' unseen values become [UNK] (README).
    # ponytail: pragmatiq treats a number as a category below 256 distinct values (MCC / ZIP codes); ages, tenure
    # and minutes have fewer, so 16 makes them ordered buckets. Pin a code that parses as a number with
    # force_categorical when real data has one.
    tok = PragmaTokenizer(TokenizerConfig.from_dict({"numeric_min_cardinality": 16, "text_value_mode": "embed",
                                                      "text_encoder": text_encoder(), "text_encoder_dim": TEXT_DIM}))
    tok.fit(SILVER / "train")
    # ponytail: pragmatiq calls a field text only above 1,000 distinct values; ours have a few dozen, so we name them.
    # Their category lists stay in the tokenizer: the views use them as the candidates a predicted vector is matched to.
    for k in TEXT_KEYS:
        if k in tok.field_kind:
            tok.field_kind[k] = "text"
    tok.save(FC / "tokenizer")
    n = forecast_records(FC)  # fit on the customers as they are; the shards add the forecast records
    m = api.tokenize(FC, TOK, tokenizer_dir=FC / "tokenizer")
    compact_index(TOK / "user_index.lmdb")
    print(f"forecast records: {n:,} (history cut at a random event + a hidden stub of the next one)")
    tok = PragmaTokenizer.load(TOK / "tokenizer")
    kinds = {k: [x for x, v in tok.field_kind.items() if v == k] for k in ("categorical", "numeric", "text")}
    print(f"tokenizer: {len(tok.key_vocab)} keys, vocabulary {tok.vocab_size:,} tokens\n" +
          "\n".join(f"  {k}: {', '.join(v) or '-'}" for k, v in kinds.items()) +
          f"\nshards -> {TOK} ({', '.join(f'{k} {v}' for k, v in m.items() if isinstance(v, int))})")


def decode_vocab(tok) -> dict[int, tuple[str, str]]:
    """value id -> (field, readable value) for categories and number buckets; text pieces: see value_text."""
    inv = {i: (k, v) for k, voc in tok.cat_vocab.items() for v, i in voc.items()}
    for k, b in tok.binners.items():
        inv.update({tok.binner_base[k] + j: (k, b.bucket_repr(j)) for j in range(b.n_bins)})
    return inv


def value_text(tok, inv: dict, vid: int) -> str:
    from pragmatiq.data.tokenizer import SPECIAL_TOKENS

    if vid < len(SPECIAL_TOKENS):
        return SPECIAL_TOKENS[vid]
    if tok.bpe is not None and vid >= tok.bpe_offset:
        return tok.bpe.id_to_token(vid - tok.bpe_offset)
    return inv.get(vid, (None, "?"))[1]


def own_values(tok, key: str) -> list[int]:
    """The value ids a field can take: its categories, its number buckets, or (text) every sub-word piece."""
    if key in tok.cat_vocab:
        return list(tok.cat_vocab[key].values())
    if key in tok.binners:
        return list(range(tok.binner_base[key], tok.binner_base[key] + tok.binners[key].n_bins))
    return list(range(tok.bpe_offset, tok.vocab_size)) if tok.bpe is not None else []


def example(tok, batch, masked, logits, text_pred=None, encode=None, max_events: int = 40) -> dict:
    """The batch's first customer as the masked-modelling step sees it: every token, which ones are hidden, and
    the model's top 3 guesses for each hidden one (among that field's own values). A hidden text field is rebuilt
    as a vector; its guesses are the known texts of that field closest to it (cosine similarity)."""
    import numpy as np
    import torch

    from pragmatiq.training.masking import TYPE_NAMES

    inv_key, inv = {v: k for k, v in tok.key_vocab.items()}, decode_vocab(tok)
    row_of = {int(t): r for r, t in enumerate(masked.selected_idx.tolist())}
    probs = logits.detach().float().softmax(-1).cpu()
    is_text = batch.is_text.cpu().bool() if batch.is_text.numel() == batch.key_ids.numel() else torch.zeros(len(batch.key_ids), dtype=torch.bool)
    text_of = dict(zip(is_text.nonzero().squeeze(1).tolist(), batch.text_values))
    tl = masked.text_loss_idx.tolist() if getattr(masked, "text_loss_idx", None) is not None else []
    trow = {int(t): r for r, t in enumerate(tl)}

    def nearest(k, vec):  # the field's known texts, ranked by how close their vector is to the predicted one
        cands = list(tok.cat_vocab.get(k, {}))
        if not cands or vec is None or encode is None:
            return []
        sim = torch.nn.functional.cosine_similarity(encode(cands).float(), vec.float().cpu()[None], dim=1)
        top = sim.topk(min(3, len(cands))).indices.tolist()
        return [[cands[i], round(float(sim[i]), 3)] for i in top]
    ev_of, keys, vals, mtype = (x.cpu() for x in (batch.event_of_token, batch.key_ids, batch.value_ids, masked.mask_type))
    events, stats = [], {"masked": 0, "right": 0, "dropped": 0}
    for e in (batch.user_of_event.cpu() == 0).nonzero().squeeze(1).tolist()[-max_events:]:
        toks = []
        for j in (ev_of == e).nonzero().squeeze(1).tolist():
            k, vid = inv_key.get(int(keys[j]), "[UNK]"), int(vals[j])
            r = {"j": j, "k": k, "v": value_text(tok, inv, vid), "m": TYPE_NAMES.get(int(mtype[j]))}
            if j in text_of:
                r.update(v=text_of[j], text=True)
            if j in trow:  # a hidden text field: the model rebuilt its vector (MSE), not a category
                g = nearest(k, text_pred[trow[j]] if text_pred is not None and trow[j] < len(text_pred) else None)
                r.update(m="text", inp="[MASK]", guess=g, ok=bool(g) and g[0][0] == r["v"])
                stats["masked"] += 1
                stats["right"] += r["ok"]
            elif r["m"] and j not in row_of:  # selected, then shown as [UNK] and left out of the loss (10%)
                r["inp"] = "[UNK]"
                stats["dropped"] += 1
            elif r["m"]:
                cand = torch.tensor(own_values(tok, k) or [vid])
                top = cand[probs[row_of[j], cand].topk(min(3, len(cand))).indices].tolist()
                r.update(inp="[MASK]", ok=top[0] == vid,
                         guess=[[value_text(tok, inv, v), round(float(probs[row_of[j], v]), 3)] for v in top])
                stats["masked"] += 1
                stats["right"] += r["ok"]
            toks.append(r)
        events.append({"ts": str(np.datetime64(int(batch.event_ts[e]), "us"))[:16].replace("T", " "), "toks": toks})
    return {"user": batch.user_ids[0], "events": events, **stats}


def watch(tok, path: Path) -> None:
    """Every optimizer step appends one example of what it trained on to `path` (JSON lines): the guesses are
    the model's before it learns from that batch, so the file shows it getting better.
    ponytail: pragmatiq has no step callback, so this wraps PreTrainer._micro_backward and reads the logits the
    step already computes (forward hook on the head): no extra forward pass. Ceiling: breaks if pragmatiq
    renames that method; then use its callback, if it gains one."""
    from pragmatiq.training.pretrainer import PreTrainer

    original = PreTrainer._micro_backward

    def micro_backward(self, batch, accum, agg, *args, **kwargs):
        if not hasattr(self, "_seen"):
            self._seen = {}
            self.head.register_forward_hook(lambda _m, _i, out: self._seen.__setitem__("logits", out))
            rebuild = self.head.reconstruct_text  # hidden text fields: keep the vectors the step predicts

            def reconstruct_text(out, idx):
                self._seen["text"] = rebuild(out, idx).detach()
                return self._seen["text"]

            self.head.reconstruct_text = reconstruct_text
        self._seen.pop("logits", None)
        self._seen.pop("text", None)
        result = original(self, batch, accum, agg, *args, **kwargs)
        if "_watched" not in agg and "logits" in self._seen and agg.get("_last_masked") is not None:
            agg["_watched"] = True  # one example per optimizer step: its first micro-batch
            masked = agg["_last_masked"]
            if masked.selected_idx.numel() == len(self._seen["logits"]):
                enc = self.model.text_encoder.encode if self.model.text_encoder is not None else None
                ex = example(tok, agg["_last_batch"], masked, self._seen["logits"], self._seen.get("text"), enc)
                with open(path, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps({"step": self.step + 1, **ex}, ensure_ascii=False) + "\n")
        return result

    PreTrainer._micro_backward = micro_backward


def forecast_masker() -> str:
    """Register pragmatiq masker "pragma_forecast": PRAGMA masking, plus the stub that ends every forecast record
    (see forecast_records) always hidden: its source and event become [MASK] and are scored."""
    import torch

    from pragmatiq.data.tokenizer import MASK
    from pragmatiq.registry import register_masker
    from pragmatiq.training.masking import T_EVENT, MaskingStrategy

    @register_masker("pragma_forecast")
    class ForecastMasking(MaskingStrategy):
        def __call__(self, batch, generator=None):
            m = super().__call__(batch, generator)
            dev = batch.key_ids.device
            fc = torch.tensor([FC_TAG in u for u in batch.user_ids], device=dev)
            last = torch.zeros(len(fc), dtype=torch.int64, device=dev).scatter_reduce(
                0, batch.user_of_event, torch.arange(batch.n_events, device=dev), "amax", include_self=False)
            stub = torch.zeros(batch.n_events, dtype=torch.bool, device=dev)
            stub[last[fc]] = True
            t = stub[batch.event_of_token]
            m.input_value_ids[t], m.labels[t], m.mask_type[t] = MASK, batch.value_ids[t].long(), T_EVENT
            m.selected_idx = (m.labels != -100).nonzero(as_tuple=False).squeeze(1)
            if m.feed_text.numel():
                m.feed_text &= ~t
            return m

    return "pragma_forecast"


def train(name: str, model_size: str, max_steps: int) -> None:
    from pragmatiq import api
    from pragmatiq.data.tokenizer import PragmaTokenizer

    if not (TOK / "shard_manifest.json").exists():
        raise SystemExit("no token shards yet: run `pipeline.py tokenize` first")
    run = MODELS / name
    shutil.rmtree(run, ignore_errors=True)  # a fresh run: an appended metrics log would mix two curves
    run.mkdir(parents=True)
    text_encoder()  # the model is built with it (pretrain reads the name from the tokenizer)
    watch(PragmaTokenizer.load(TOK / "tokenizer"), run / "examples.jsonl")
    # ponytail: fixed small-book schedule. config="auto" targets 1M+ record books; on 5k customers it plans
    # 2 optimizer steps x 64 grad-accum. Switch to config="auto" once the real book is that large.
    s = api.pretrain(TOK, name, model_size=model_size, runs_root=MODELS,
                     config={"max_steps": max_steps, "token_budget": 8192,
                             "warmup_steps": max(10, max_steps // 10), "devices": 1, "masker": forecast_masker()})
    print(f"trained {model_size} -> {s['run_dir']}")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("silver", help="data/bronze -> data/silver/{train,test} (validated pragmatiq contract)")
    sub.add_parser("tokenize", help="fit the tokenizer on data/silver/train, write shards -> data/gold/tok")
    sub.add_parser("prepare", help="silver, then tokenize")
    t = sub.add_parser("train", help="pretrain the event model on data/gold/tok -> models/<name>")
    t.add_argument("--name", default="events")
    t.add_argument("--model-size", default="nano", choices=["nano", "small", "medium", "large"])
    t.add_argument("--max-steps", type=int, default=600, help="nano on ~5k customers: ~10 min on a CPU")
    a = p.parse_args()
    if a.cmd == "silver":
        silver()
    elif a.cmd == "tokenize":
        tokenize()
    elif a.cmd == "prepare":
        silver()
        tokenize()
    else:
        train(a.name, a.model_size, a.max_steps)


if __name__ == "__main__":
    if not os.environ.get("BYO_REEXEC") and (find_spec("pragmatiq") is None or not sys.flags.utf8_mode):
        py = Path(sys.executable)
        if find_spec("pragmatiq") is None:
            if not VENV_PY.exists():
                sys.exit("no .venv with pragmatiq yet: run ./start.sh once")
            py = VENV_PY
        sys.exit(subprocess.call([str(py), __file__, *sys.argv[1:]],
                                 env={**os.environ, "PYTHONUTF8": "1", "BYO_REEXEC": "1"}))
    main()
