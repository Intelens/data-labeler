#!/usr/bin/env bash
# The guided demo, from a fresh machine with only this folder:  ./start.sh  ->  http://localhost:8000
# Needs bash and curl. The first run installs uv, Python 3.11 and the packages into .venv (a few minutes);
# later runs start straight away. The folder ships with a finished demo (data/, models/, work/, webapp/data);
# every step can be re-run from the web app.
#   PORT=8080 ./start.sh          another port
#   HOST=0.0.0.0 ./start.sh       reachable from other machines (no login: only on a trusted network);
#                                 otherwise from your laptop: ssh -L 8000:localhost:8000 <vm>
# A GPU is used when nvidia-smi is present (CUDA build of torch); without one the small CPU build is installed.
set -euo pipefail
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:$PATH"
command -v uv >/dev/null || curl -LsSf https://astral.sh/uv/0.11.8/install.sh | sh
case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) PY=.venv/Scripts/python.exe ;; *) PY=.venv/bin/python ;; esac
[ -x "$PY" ] || rm -rf .venv  # none yet, or one copied from another machine / OS: build it here
if [ ! -f .venv/installed ]; then
  [ -d .venv ] || uv venv --python 3.11 .venv
  command -v nvidia-smi >/dev/null || uv pip install --python .venv torch==2.14.1 --index-url https://download.pytorch.org/whl/cpu
  # pinned to the versions the shipped model and webapp/data/heads.pkl were made with
  uv pip install --python .venv "pragmatiq[train]==1.1.0" torch==2.14.1 numpy==2.4.6 pandas==3.0.6 \
    pyarrow==26.0.0 scikit-learn==1.9.1
  touch .venv/installed
fi
PYTHONUTF8=1 exec "$PY" webapp/server.py --host "${HOST:-127.0.0.1}" --port "${PORT:-8000}"
