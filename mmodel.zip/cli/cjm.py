"""Synthetic customer journeys from a definition JSON (step 1 of the guide in webapp/server.py).

  python cli/cjm.py generate cli/example_definition.json --n-users 2000

Writes data/bronze (one raw text file per customer), work/raw (the same events, validated in
pragmatiq's contract), work/truth.parquet (hidden truth) and work/definition.json.
Any python can launch this: it re-runs itself under .venv (Python 3.11 with pragmatiq
installed, made by start.sh) in UTF-8 mode, which the tokenizer needs on Windows.

Definition JSON (see cli/example_definition.json):
  events            {name: {role, family, source, fields, delay_minutes, next}}
                    role:     "action" for what the bank does (email sent, push sent, call made):
                              sent at random hours with random content, and the reaction depends
                              on how well the hour and the channel suit the customer;
                              "reaction" for what the customer does (opened, answered, visited)
                    family:   outreach | engagement | conversion | risk (colours in the web app)
                    source:   transaction | app | trading | communication
                    next:     {event_name | "end": weight}; no next = journey ends
  start             {event_name: weight} - first event of each journey
  profile           per-customer attributes (field specs)
  journey_fields    sampled once per journey and added to every event in it; an event
                    whose own fields set one (an email's topic) steers the rest of the journey
  personalize       {"field", "strength"}: each customer gets a hidden affinity over that
                    journey field's values; organic journeys follow it, and every funnel step
                    is (n_values * affinity) ** strength times likelier.
  active_hours      {"peaks", "spread", "strength"}: each customer gets a hidden favourite hour
                    (a peak + noise); organic journeys start around it, and reactions to an
                    action are (0.2 + 1.8 * fit) ** strength times likelier, fit = how close the
                    action's hour is to the favourite one.
  channel_preference {"strength"}: each customer gets a hidden preference over the action events
                    (email, push, phone, ...); reactions to an action are
                    (n_actions * preference) ** strength times likelier.
  profile_effects   {numeric profile attribute: {channel or topic: coefficient}}: tilts the hidden
                    preferences, e.g. older customers lean to phone, higher income to investing
                    (weight * exp(coef * z), z = the attribute scaled to -1..1 over its min..max).
  journeys_per_user, start_date, days, user_variation (per-customer propensity spread)
Field spec: "x" = constant, ["a", "b"] = random choice, {"min": 1, "max": 9} = uniform number,
  [{...}, {...}] = content items (subject lines, banners, contact notes): one is picked, its keys
  become event fields and its "appeal" scales the customer's response.
  Text may reference journey fields and the event's earlier fields: "{reason}: asked about {topic}".
Hidden truth (affinities, favourite hour) -> work/truth.parquet, the event that started each event's journey ->
work/journeys.parquet (scores attribution, deliverable 4), definition -> work/definition.json.
Bronze layer: data/bronze/<customer>.txt, one raw event per line, tab-separated:
  timestamp  source  event  key=value  key=value ...
and data/bronze/profiles.txt, one customer per line:  customer_id  key=value  key=value ...
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
import os
import subprocess
import sys
from importlib.util import find_spec
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENV_PY = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")  # made by start.sh
EXAMPLE = Path(__file__).with_name("example_definition.json")
WORK = ROOT / "work"
BRONZE = ROOT / "data" / "bronze"
MAX_STEPS = 50  # ponytail: hard cap per journey so a self-loop (page -> page) can't run forever
DAY_US, HOUR_US = 86_400_000_000, 3_600_000_000


def is_action(ev: dict) -> bool:
    """Bank-initiated event (email sent, push sent, call made). `outbound` is the older spelling."""
    return ev.get("role") == "action" or bool(ev.get("outbound"))


def _sample(spec, rng):
    if isinstance(spec, str):
        return spec
    if isinstance(spec, list):
        return spec[rng.integers(len(spec))]
    if isinstance(spec, dict) and spec.keys() == {"min", "max"}:
        if isinstance(spec["min"], int) and isinstance(spec["max"], int):
            return int(rng.integers(spec["min"], spec["max"] + 1))
        return round(float(rng.uniform(spec["min"], spec["max"])), 2)
    raise SystemExit(f"bad field spec {spec!r}: use a string, a list of choices, or {{\"min\", \"max\"}}")


def _pick(weights, bias, rng, lift=1.0):
    weights = weights or {"end": 1}
    keys = list(weights)
    p = [weights[k] * bias[k] * (1.0 if k == "end" else lift) for k in keys]
    return keys[rng.choice(len(keys), p=[w / sum(p) for w in p])]


def _check(d):
    from pragmatiq.core.schema import SOURCES

    events = d["events"]
    for name, ev in events.items():
        if ev.get("source") not in SOURCES:
            raise SystemExit(f"event {name!r}: source must be one of {list(SOURCES)}, got {ev.get('source')!r}")
        for target in ev.get("next", {}):
            if target != "end" and target not in events:
                raise SystemExit(f"event {name!r}: next -> unknown event {target!r}")
    if not d["start"]:
        raise SystemExit("start: no enabled start events")
    for target in d["start"]:
        if target not in events:
            raise SystemExit(f"start -> unknown event {target!r}")
    pz = d.get("personalize")
    if pz and len(d.get("journey_fields", {}).get(pz["field"], [])) < 2:
        raise SystemExit(f"personalize: journey_fields.{pz['field']} needs a list of at least 2 values")
    if d.get("active_hours") and not d["active_hours"].get("peaks"):
        raise SystemExit("active_hours: peaks needs at least one hour")


def generate(d: dict, n_users: int, seed: int) -> str:
    """Write work/raw (pragmatiq data contract) + work/truth.parquet from a definition dict."""
    import numpy as np
    import pyarrow as pa
    import pyarrow.parquet as pq

    from pragmatiq import api
    from pragmatiq.core.schema import EVENTS_SCHEMA, PROFILES_SCHEMA

    _check(d)
    events, jf, pz, ah = d["events"], d.get("journey_fields", {}), d.get("personalize"), d.get("active_hours")
    cp = d.get("channel_preference")
    choices = jf[pz["field"]] if pz else []
    channels = [k for k, v in events.items() if is_action(v)] if cp else []
    rng = np.random.default_rng(seed)
    t0 = int(np.datetime64(d.get("start_date", "2026-01-01"), "us").astype(np.int64))
    t_end = t0 + d.get("days", 90) * DAY_US
    ev_cols: dict[str, list] = {"user_id": [], "ts": [], "source": [], "fields": []}
    prof: dict[str, list] = {"user_id": [], "as_of": [], "attributes": [], "lifelong": []}
    truth: dict[str, list] = {"user_id": [], **{c: [] for c in choices}, **({"fav_hour": []} if ah else {}),
                              **{f"pref:{c}": [] for c in channels}}
    jt: dict[str, list] = {"user_id": [], "ts_us": [], "event": [], "start": []}  # which event started each event's journey
    BRONZE.mkdir(parents=True, exist_ok=True)
    for old in BRONZE.glob("*.txt"):  # a smaller regeneration must not leave stale customers behind
        old.unlink()

    prof_spec, profile_lines = d.get("profile", {}), []
    for i in range(n_users):
        uid = f"c_{i:05d}"
        attrs = {k: _sample(s, rng) for k, s in prof_spec.items()}  # first: the hidden traits lean on it
        # Per-customer propensity per event: individual behaviour, not just segment-level (what the FM can learn).
        bias = dict(zip([*events, "end"], rng.lognormal(0, d.get("user_variation", 0.5), len(events) + 1)))
        aff = dict(zip(choices, rng.dirichlet(np.ones(len(choices))))) if pz else {}
        fav = (rng.choice(ah["peaks"]) + rng.normal(0, 1)) % 24 if ah else 0.0
        pref = dict(zip(channels, rng.dirichlet(np.ones(len(channels))))) if channels else {}
        for a, coefs in d.get("profile_effects", {}).items():  # e.g. older -> phone, higher income -> investing
            spec = prof_spec.get(a)
            if isinstance(spec, dict) and spec.get("max", 0) > spec.get("min", 0):
                z = 2 * (float(attrs[a]) - spec["min"]) / (spec["max"] - spec["min"]) - 1
                for trait in (aff, pref):
                    for k in trait.keys() & coefs.keys():
                        trait[k] *= np.exp(coefs[k] * z)
        for trait in (aff, pref):
            total = sum(trait.values())
            for k in trait:
                trait[k] /= total
        rows = []
        for _ in range(_sample(d.get("journeys_per_user", {"min": 1, "max": 5}), rng)):
            step = _pick(d["start"], bias, rng)
            first = step
            organic = ah and not is_action(events[step])  # customer-started journeys happen at their hours
            hour = (fav + rng.normal(0, ah["spread"])) % 24 if organic else rng.uniform(0, 24)
            ts = t0 + int(rng.integers(d.get("days", 90))) * DAY_US + int(hour * HOUR_US)
            ctx = {k: str(_sample(s, rng)) for k, s in jf.items()}
            if pz:  # organic journeys follow the customer's taste
                ctx[pz["field"]] = choices[rng.choice(len(choices), p=list(aff.values()))]
            for n_step in range(MAX_STEPS):
                if step == "end":
                    break
                ev = events[step]
                if n_step:  # the journey starts at its first event; delays only separate the steps after it
                    ts += int(_sample(ev.get("delay_minutes", {"min": 1, "max": 1440}), rng) * 60_000_000)
                if ts >= t_end:  # observation window ends: later steps are not in the extract
                    break
                own, appeal = {}, 1.0
                for k, s in ev.get("fields", {}).items():
                    v = _sample(s, rng)
                    if isinstance(v, dict):  # content item: its keys become fields, its appeal scales the response
                        appeal *= v.get("appeal", 1.0)
                        pairs = [(ck, cv) for ck, cv in v.items() if ck != "appeal"]
                    else:
                        pairs = [(k, v)]
                    for ck, cv in pairs:  # text may reference journey/earlier fields: "asked about {topic}"
                        cv = str(cv)
                        own[ck] = cv.format_map(defaultdict(str, {**ctx, **own})) if "{" in cv else cv
                ctx.update({k: v for k, v in own.items() if k in jf})
                rows.append((ts, ev["source"], list({"event": step, **ctx, **own}.items()), first))
                lift = appeal
                if pz:
                    lift *= (len(choices) * aff.get(ctx[pz["field"]], 1 / len(choices))) ** pz["strength"]
                if ah and is_action(ev):  # did the action land at an hour that suits this customer?
                    off = abs((ts / HOUR_US - fav + 12) % 24 - 12)
                    lift *= (0.2 + 1.8 * np.exp(-off**2 / (2 * ah["spread"] ** 2))) ** ah.get("strength", 1.0)
                if step in pref:  # and through a channel this customer likes?
                    lift *= (len(channels) * pref[step]) ** cp["strength"]
                step = _pick(ev.get("next"), bias, rng, lift)
        rows.sort(key=lambda r: r[0])
        (BRONZE / f"{uid}.txt").write_text("".join(
            f"{np.datetime64(ts, 'us')}\t{source}\t{fields[0][1]}\t" + "\t".join(f"{k}={v}" for k, v in fields[1:]) + "\n"
            for ts, source, fields, _ in rows), encoding="utf-8")
        for ts, source, fields, first in rows:
            ev_cols["user_id"].append(uid)
            ev_cols["ts"].append(ts)
            ev_cols["source"].append(source)
            ev_cols["fields"].append(fields)
            for k, v in zip(jt, (uid, ts, fields[0][1], first)):
                jt[k].append(v)
        prof["user_id"].append(uid)
        prof["as_of"].append(rows[-1][0])
        prof["attributes"].append([(k, str(v)) for k, v in attrs.items()])
        prof["lifelong"].append([])
        profile_lines.append("\t".join([uid, *(f"{k}={v}" for k, v in attrs.items())]) + "\n")
        truth["user_id"].append(uid)
        for c in choices:
            truth[c].append(aff[c])
        if ah:
            truth["fav_hour"].append(fav)
        for c in channels:
            truth[f"pref:{c}"].append(pref[c])

    (BRONZE / "profiles.txt").write_text("".join(profile_lines), encoding="utf-8")
    raw = WORK / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    (WORK / "definition.json").write_text(json.dumps(d, indent=2), encoding="utf-8")
    pq.write_table(pa.Table.from_pydict(ev_cols, schema=EVENTS_SCHEMA), raw / "events.parquet")
    pq.write_table(pa.Table.from_pydict(prof, schema=PROFILES_SCHEMA), raw / "profiles.parquet")
    pq.write_table(pa.Table.from_pydict(truth), WORK / "truth.parquet")
    pq.write_table(pa.Table.from_pydict(jt), WORK / "journeys.parquet")
    report = api.validate(raw)
    if not report["ok"]:
        raise SystemExit("\n".join(report["errors"]))
    return f"{len(ev_cols['ts'])} events for {n_users} customers -> {raw}, {BRONZE} ({report['summary']})"


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("generate", help="synthetic journeys from a definition JSON -> data/bronze")
    g.add_argument("definition", type=Path)
    g.add_argument("--n-users", type=int, default=2000)
    g.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    print(generate(json.loads(a.definition.read_text(encoding="utf-8")), a.n_users, a.seed))


if __name__ == "__main__":
    if not os.environ.get("CJM_REEXEC") and (find_spec("pragmatiq") is None or not sys.flags.utf8_mode):
        py = Path(sys.executable)
        if find_spec("pragmatiq") is None:
            if not VENV_PY.exists():
                sys.exit("no .venv with pragmatiq yet: run ./start.sh once")
            py = VENV_PY
        sys.exit(subprocess.call([str(py), __file__, *sys.argv[1:]],
                                 env={**os.environ, "PYTHONUTF8": "1", "CJM_REEXEC": "1"}))
    main()
